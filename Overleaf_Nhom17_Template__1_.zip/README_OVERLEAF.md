# Bộ khung báo cáo Overleaf - Nhóm 17

## 1. Cách đưa lên Overleaf
1. Giải nén tệp ZIP.
2. Truy cập Overleaf và chọn **New Project > Upload Project**.
3. Tải lên toàn bộ ZIP này.
4. Mở **Menu > Compiler**, chọn **XeLaTeX**.
5. Chọn `main.tex` làm Main document nếu Overleaf chưa tự nhận.
6. Recompile để tạo PDF.

## 2. Cấu trúc
- `main.tex`: tệp chính, cấu hình định dạng và ghép các chương.
- `cover/cover.tex`: trang bìa.
- `chapters/chapter1.tex` ... `chapter6.tex`: sáu chương theo đúng thứ tự yêu cầu.
- `chapters/appendix.tex`: phụ lục.
- `figures/eda/`: biểu đồ EDA.
- `figures/results/`: biểu đồ kết quả mô hình.
- `figures/pipeline/`: sơ đồ quy trình.
- `references.bib`: tài liệu tham khảo.

## 3. Hình ảnh đã chuẩn bị
Một số biểu đồ EDA và Confusion Matrix được lấy từ thư mục `Results` của dự án:
- `01_phan_phoi_nhan.png`
- `02_du_lieu_thieu.png`
- `03_ma_tran_tuong_quan.png`
- `confusion_KNN_Pipeline_A_K9.png`

## 4. Các nội dung cần nhóm tự cập nhật
- Tên trường, khoa, học phần, giảng viên, thành viên và mã sinh viên.
- Số liệu EDA được xác nhận từ lần chạy thực tế.
- Kết quả Baseline (cần bổ sung thí nghiệm).
- Bảng phân tích lỗi theo file kết quả mới nhất.
- Nội dung nhận xét và kết luận dựa trên kết quả thật.
- Nguồn dữ liệu chính xác và ngày truy cập tài liệu.

## 5. Lưu ý học thuật
- Không đưa kết quả giả định vào báo cáo.
- Kết quả bảng mô hình hiện được điền từ `Results/model_comparison.csv` của lần chạy đã cung cấp.
- Nên bổ sung Validation độc lập nếu dùng Test để lựa chọn mô hình.
- Cần kiểm tra các đặc trưng có thể phát sinh sau thời điểm dự đoán để tránh data leakage.
